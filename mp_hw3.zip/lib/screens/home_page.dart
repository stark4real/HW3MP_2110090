import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue,
      appBar: AppBar(
        title: Text('One Piece World'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Welcome to One Piece World!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            Icon(
              Icons.favorite,
              size: 50,
              color: Colors.white,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/luffy');
              },
              child: Text('Explore Luffy'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/zoro');
              },
              child: Text('Explore Zoro'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/usopp');
              },
              child: Text('Explore Usopp'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/nami');
              },
              child: Text('Explore Nami'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/sanji');
              },
              child: Text('Explore Sanji'),
            ),
          ],
        ),
      ),
    );
  }
}
