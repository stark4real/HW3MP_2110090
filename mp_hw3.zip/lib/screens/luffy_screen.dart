import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mp_hw3/providers/character_provider.dart';

class LuffyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var characterProvider = Provider.of<CharacterProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Monkey D. Luffy'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(
              Icons.anchor,
              size: 100,
            ),
            Text(
              'Monkey D. Luffy',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            Text(characterProvider.luffyInfo),
            ElevatedButton(
              onPressed: () {
                characterProvider
                    .updateLuffyInfo('New information about Luffy');
              },
              child: Text('Update Info'),
            ),
            SizedBox(height: 20),
            Text(
              'Captain of the Straw Hat Pirates and the protagonist of the series.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
