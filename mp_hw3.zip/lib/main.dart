import 'dart:js';

import 'package:flutter/material.dart';
import 'package:mp_hw3/screens/zoro_screen.dart';
import 'package:provider/provider.dart';
import 'package:mp_hw3/providers/character_provider.dart';
import 'package:mp_hw3/screens/home_page.dart';
import 'package:mp_hw3/screens/luffy_screen.dart';
// Import other character screens similarly

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => CharacterProvider(),
      child: MaterialApp(
        title: 'One Piece World',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => HomePage(),
          '/luffy': (context) => LuffyScreen(),
          '/zoro': (context) => ZoroScreen(),
          '/usopp': (context) => UsoppScreen(),
          '/nami': (context) => NamiScreen(),
          '/sanju': (context) => SanjiScreen(),
          // Add routes for other characters similarly
        },
      ),
    ),
  );
}
