import 'package:flutter/material.dart';

class CharacterProvider extends ChangeNotifier {
  String luffyInfo = 'Some information about Luffy';

  void updateLuffyInfo(String newInfo) {
    luffyInfo = newInfo;
    notifyListeners();
  }
}
