package com.example.mp_hw3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
